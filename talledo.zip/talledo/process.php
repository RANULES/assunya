<?php
session_start();    
include("config.php");

if(isset($_POST["insertButton"])){

    $student_id = $_POST['student_id'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $birthday = $_POST['birthday'];
    $email_address = $_POST['email_address'];

    $query = "INSERT INTO `student_information`(`student_id`, `fname`, `mname`, `lname`, `birthday`, `email_address`) VALUES (`$student_id', '$fname','$mname','$lname','$birthday','$email_address)";
    $query_result = mysqli_query( $con, $query );

    if($query_result){
        $_SESSION['status'] = "Insert Student Success!";
        $_SESSION['status_code'] = "success";
        header("Location: index.php");
        exit();
    }

}

   /* $birthday = isset($_POST['mname']) ? $_POST['mname'] : '' ;
    $lname = $_POST['lname']; */

    /* $check_email_query = "SELECT * FROM `user` WHERE `email` = '$email'";
    $email_result = mysqli_query($con,$check_email_query);
    $email_count = mysqli_fetch_array($email_result)[0];
    */

    /*
    if($email_count > 0){
        $_SESSION['status'] = "Email address already taken";
        $_SESSION['status_code'] = "error";
        header("Location: register.php");
        exit();
    }
*/
    /* if ($password !== $repassword){
        $_SESSION['status'] = "Password does not match";
        $_SESSION['status_code'] = "error";
        header("Location: register.php");
        exit();
    }
    */

/*
    $query = "INSERT INTO `user`(`student_id`, `fname`, `mname`, `lname`, `birthday` , `email_address`) VALUES ('$student_id','$fname','$mname','$lname','$birthday', `$email_address`)";
    $query_result = mysqli_query( $con, $query );

    if($query_result){
        $_SESSION['status'] = "Registration Sucess!";
        $_SESSION['status_code'] = "success";
        header("Location: login.php");
        exit();
    }
}
*/


/* if(isset($_POST["loginButton"])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $login_query = "INSERT INTO `student_information`(`studentId`, `fname`, `mname`, `lname`, `birthday`, `address`, `dateCreated`) VALUES ('$studentId','$fname','$mname','$lname','$birthday','$address','$dateCreated')";
    $login_result = mysqli_query($con, $login_query);

    if(mysqli_num_rows($login_result) == 1){
            $_SESSION['status'] = "Welcome!";
            $_SESSION['status_code'] = "success";
            header("Location: index.php");
            exit();
    }else{
        $_SESSION['status'] = "Invalid Username/Password";
        $_SESSION['status_code'] = "error";
        header("Location: login.php");
        exit();
    }
}
*/

?>